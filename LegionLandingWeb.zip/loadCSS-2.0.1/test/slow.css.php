<?php
sleep(5);
header( "Content-type: text/css; charset: UTF-8; Cache-Control: max-age=500" );
?>
/* This file was delivered after a purposeful 5 second delay to demonstrate latency. */
body { background: green; color: #fff; }
