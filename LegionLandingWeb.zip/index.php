<?php
error_reporting(0);
header('Content-Type: text/html; charset=utf-8'); 
?>
<!DOCTYPE html>
<html lang=en>
<head>
<meta charset=utf-8>
<script async src=https://cdn.ampproject.org/v0.js></script>
<meta http-equiv=X-UA-Compatible content="IE=edge">
<meta name=viewport content="width=device-width, initial-scale=1">
<title>Legión Creativa</title>
<meta name=Keywords content>
<meta name=Description content=""/>
<link href=css/bootstrap.min.css rel=preload as=style onload="this.rel='stylesheet'">
<link href=css/font-awesome/css/font-awesome.min.css rel=preload as=style onload="this.rel='stylesheet'">
<style>#slider{position:relative;overflow:hidden;margin:20px auto 0 auto;border-radius:4px}#slider ul{position:relative;margin:0;padding:0;height:200px;list-style:none}#slider ul li{position:relative;display:block;float:left;margin:0;padding:0;width:500px;height:300px;background:transparent;text-align:center;line-height:300px}a.control_prev,a.control_next{position:absolute;top:40%;z-index:999;display:block;padding:4% 3%;width:auto;height:auto;background:#2a2a2a;color:#fff;text-decoration:none;font-weight:600;font-size:18px;opacity:.8;cursor:pointer}a.control_prev:hover,a.control_next:hover{opacity:1;-webkit-transition:all .2s ease}a.control_prev{border-radius:0 2px 2px 0}a.control_next{right:0;border-radius:2px 0 0 2px}.slider_option{position:relative;margin:10px auto;width:160px;font-size:18px}.img-slider{height:110%;margin-left:9%}.slider-row{padding-bottom:60px}</style>
<link href=css/styles.min.css rel=stylesheet>
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800|Ubuntu:300,400,500,700" rel=preload as=style onload="this.rel='stylesheet'">
<script type=application/ld+json>
      {
        "@context": "http://schema.org",
        "@type": "NewsArticle",
        "headline": "Open-source framework for publishing content",
        "datePublished": "2015-10-07T12:02:41Z",
        "image": [
          "logo.jpg"
        ]
      }
    </script>
<script>(function(){var a=document.createElement("script");a.type="text/javascript";a.async=true;a.src="https://s.cliengo.com/weboptimizer/59cd54cee4b09220e41154c9/59cd54d4e4b09220e41154d6.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)})();</script>
<script>(function(d,e,j,h,f,c,b){d.GoogleAnalyticsObject=f;d[f]=d[f]||function(){(d[f].q=d[f].q||[]).push(arguments)},d[f].l=1*new Date();c=e.createElement(j),b=e.getElementsByTagName(j)[0];c.async=1;c.src=h;b.parentNode.insertBefore(c,b)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create","UA-42302381-1","legioncreativa.com.ar");ga("send","pageview");</script>
</head>
<body>
<header>
<div class=container>
<div class=row>
<div class=col-sm-4>
<amp-img src=imagenes/logo.png width=270 height=138 alt id=logo /></amp-img>
</div>
<div class="col-sm-8 text-right">
<div class=separador></div><div class=clearfix></div>
<h1>Desarrollamos sitios web<br />100% personalizados.</h1>
</div>
</div>
</div>
</header>
<div class=container>
<div class="row slider-row">
<div class=col-sm-6>
<div id=slider>
<a href=# class=control_next>></a>
<a href=# class=control_prev><</a>
<ul>
<li>
<a href="../templates/web1"target=_blank>
<amp-img src=img/1.png width=380 height=300 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web2"target=_blank>
<amp-img src=img/2.png width=380 height=300 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web3"target=_blank>
<amp-img src=img/3.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web4"target=_blank>
<amp-img src=img/4.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web5"target=_blank>
<amp-img src=img/5.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web6"target=_blank>
<amp-img src=img/6.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web7"target=_blank>
<amp-img src=img/7.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web8"target=_blank>
<amp-img src=img/8.png width=380 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
<li>
<a href="../templates/web9"target=_blank>
<amp-img src=img/9.png width=411 height=330 class="img-slider img-responsive" alt="Templates predeterminados"></amp-img>
</a>
</li>
</ul>
</div>
</div>
<div class="col-sm-6 text-center">
<div id=contenedor_llamanos>
<amp-img src=imagenes/icono_llamanos.png id=icono_llamanos width=80 height=80 /></amp-img><br />
<div id=llamanos>¡Llamanos!</div>
<div id=telefono_llamanos>11 5263 8247</div>
<div class=separador></div><div class=clearfix></div>
</div>
</div>
</div>
<div class=row>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div id=formulario>
<div id=dejanos_consulta>DEJANOS <span>TU CONSULTA</span></div>
<div id=contactanos>Contactanos y empezaremos a pensar <span>tu sitio web</span></div>
<form name=form_contacto id=form_contacto onsubmit="enviarFormulario();return false">
<input class=campo_contacto type=text name=nombre placeholder="Nombre y Apellido" required />
<input class=campo_contacto type=text name=telefono placeholder=Teléfono required />
<input class=campo_contacto type=email name=email placeholder=Mail required />
<textarea class=campo_contacto name=mensaje style=height:70px placeholder=Mensaje required></textarea>
<input type=number id=cant_sec name=cantidadSecciones class="campo_contacto form-control text-center" style=float:left;width:40%;margin-left:15%;text-align:left placeholder="Cantidad de secciones">
<label for=autoadmin class=left style=margin-left:3%>¿El sitio sera autoadministrable?</label>
<input type=checkbox name=autoadmin id=autoadmin value=1 style=float:left;margin-left:3%>
<div class=row style=margin-top:1%>
<div class="col-sm-8 col-xs-12 text-center">
<div class=g-recaptcha data-sitekey=6Lc3SjIUAAAAAB5Ytk1LBkwj-RXNQCTDEm7DjCqD style=margin-left:22%></div>
</div>
<div class="col-sm-4 col-xs-12 text-center" style=padding:2%>
<button id=btn_enviar_contacto class="btn btn-primary" type=submit name=submit>Enviar</button></div>
</div>
<div class=clear></div>
<div class=msg-error></div>
<div id=resultado style=color:#00aeef;font-size:16px;margin-top:10px></div>
</form>
</div>
</div>
</div>
</div>
<div class=row>
<div class="col-sm-3 item_dest"><amp-img src=imagenes/1.png alt width=100 height=90 class=icono_dest></amp-img><br />PÁGINAS<br />E-COMMERCE<div class=linea_item_dest></div></div>
<div class="col-sm-3 item_dest"><amp-img src=imagenes/2.png alt width=100 height=90 class=icono_dest></amp-img><br />RESPONSIVE<br />DESIGN<div class=linea_item_dest></div></div>
<div class="col-sm-3 item_dest"><amp-img src=imagenes/3.png alt width=100 height=90 class=icono_dest></amp-img><br />WEB AUTO<br />ADMINISTRABLE<div class=linea_item_dest></div></div>
<div class="col-sm-3 item_dest"><amp-img src=imagenes/4.png alt width=100 height=90 class=icono_dest></amp-img><br />LANDING<br />PAGE<div class=linea_item_dest></div></div>
</div>
<br /><br /><br />
<div class=row>
<div class="col-sm-12 text-center"><h2 style=color:#ffc50f>Diseños con <span>TEMPLATES PREDETERMINADOS</span></h2><div class=linea_item_dest style=background:#ffc50f></div><br /></div>
</div>
<div class=row>
<div class=col-sm-4>
<amp-img src=imagenes/t1.jpg srcset="imagenes/t1-xs.jpg 320w,
           			imagenes/t1-sm.jpg 236w" width=430 height=430 alt class=img_full layout=responsive></amp-img><br /><br />
</div>
<div class=col-sm-4>
<amp-img src=imagenes/t2.jpg srcset="imagenes/t2-xs.jpg 320w,
           			imagenes/t2-sm.jpg 236w" width=430 height=430 alt class=img_full layout=responsive>
</amp-img><br /><br />
</div>
<div class=col-sm-4>
<amp-img src=imagenes/t3.jpg srcset="imagenes/t3-xs.jpg 320w,
           			imagenes/t3-sm.jpg 236w" width=430 height=430 alt class=img_full layout=responsive>
</amp-img><br /><br />
</div>
</div>
</div>
<div id=bloque_amarillo>
<div id=linea_cel1></div><div class=clearfix></div>
<div class=container>
<div class=row>
<div class="col-sm-12 text-center"><h2>Sumate al <span>MUNDO ONLINE</span></h2><div class=linea_item_dest style=background:#000></div><br /></div>
</div>
<div class=row>
<div class=col-sm-6>
<amp-img src=imagenes/foto1.png srcset="imagenes/foto1-xs.png 330w,
           			imagenes/foto1-sm.png 345w" alt width=555 height=328 class=img_full layout=responsive>
</amp-img>
<br>
</div>
<div class=col-sm-6>
<img src=imagenes/foto2.png srcset="imagenes/foto2-xs.jpg 381w,
           			imagenes/foto2-sm.jpg 345w" alt class=img_full />
</div>
</div>
</div>
<div id=linea_cel2></div><div class=clearfix></div>
<div class=container><div id=pico><img src=imagenes/pico.png alt /></div></div>
</div>
<div class=container>
<div class=row>
<div class=col-sm-12>
<div id=escribinos>¡Escribinos!</div>
<div id=mail><a href=mailto:info@legioncreativa.com>info@legioncreativa.com</a></div>
<div class=separador2></div><div class=clearfix></div>
</div>
</div>
</div>
<footer>
<div class=container>
<div class=row>
<div class="col-sm-2 text_center_mobile"><img src=imagenes/logo_footer.png alt id=logo_footer /></div>
<div class="col-sm-9 text_center_mobile text-center">
<div id=central_footer>
<a><i class="fa fa-map-marker" aria-hidden=true></i> Catamarca 1150 - San Isidro</a>
<a href=mailto:info@legioncreativa.com><i class="fa fa-envelope-o" aria-hidden=true></i> info@legioncreativa.com</a>
<a href=http://www.legioncreativa.com.ar/ target=_blank id=web>www.legioncreativa.com</a>
</div>
</div>
<div class="col-sm-1 text_center_mobile text-right" id=sociales_footer>
<a href=https://www.facebook.com/LegionCreativa target=_blank><i class="fa fa-facebook" aria-hidden=true style=margin-left:0></i></a>
<a href=https://www.instagram.com/legioncreativa/ target=_blank><i class="fa fa-instagram" aria-hidden=true></i></a>
</div>
</div>
</div>
</footer>
<script src=js/jquery-latest.min.js type=text/javascript></script>
<script async src=js/slider.js></script>
<script async src=js/bootstrap.min.js></script>
<script async src=https://www.google.com/recaptcha/api.js></script>
</body>
</html>